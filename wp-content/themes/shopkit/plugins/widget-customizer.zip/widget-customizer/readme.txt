Widget Customizer for Wordpress
by mihajlovicnenad.com!

/* UPDATES */

+ Widget Customizer 1.1
- added Import/Export functions
- added translation ready
- fixed background image upload input