(function($){

	"use strict";

	window.wfsm_frame = {};
	window.wfsm_frame_gallery = {};
	window.wfsm_frame_files = {};

})(jQuery);