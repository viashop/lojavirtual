<div class="isb_sale_badge isb_special <?php echo $isb_class; ?>">
	<span class="isb_special_text"><?php echo $isb_curr_set['special_text']; ?></span>
</div>