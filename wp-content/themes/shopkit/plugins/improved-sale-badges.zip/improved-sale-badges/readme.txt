Improved Sale Badges for WooCommerce v2.4.2!
by Mihajlovicnenad.com

Read documentation for more information!