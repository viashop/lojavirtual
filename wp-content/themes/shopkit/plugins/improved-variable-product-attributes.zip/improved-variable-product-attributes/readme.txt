Improved Variable Product Attributes for WooCommerce v3.2.5!
by Mihajlovicnenad.com

Read documentation for more information!